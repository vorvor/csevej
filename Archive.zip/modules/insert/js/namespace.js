(function(Drupal) {
  'use strict';

  Drupal.insert = Drupal.insert || {};
})(Drupal);
