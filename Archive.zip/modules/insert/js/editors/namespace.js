(function(Drupal) {
  'use strict';

  Drupal.insert.editors = Drupal.insert.editors || {};
  Drupal.insert.editors.interfaces = Drupal.insert.editors.interfaces || {};
})(Drupal);
