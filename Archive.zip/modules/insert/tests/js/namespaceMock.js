'use strict';

var Drupal = {};
Drupal.insert = {};
