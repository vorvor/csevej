Easy Install

INTRODUCTION
------------

This module built to resolve or avoid the error "Unable to install
already exists active configuration" when re installing/un installing 
the drupal 8 modules.

 * For a full description of the module, visit the project page:
   https://drupal.org/project/easy_install

 * To submit bug reports and feature suggestions, or to track changes:
   https://drupal.org/project/issues/easy_install

INSTALLATION
------------
 
 * Install as you would normally install a contributed Drupal module. 
   Visit:
    https://drupal.org/documentation/install/modules-themes/modules-7
   for further information.

CONFIGURATION
-------------

 The module has no menu or modifiable settings. There is no configuration. 
 When enabled, it will have extra checkboxes on module uninstallation form and 
 it will have new tab on module install page "Purge Configurations".

MAINTAINERS
-----------

Current maintainers:

 * Karthikeyan Manivasagam (karthikeyan-manivasagam)
     - https://www.drupal.org/u/karthikeyan-manivasagam
